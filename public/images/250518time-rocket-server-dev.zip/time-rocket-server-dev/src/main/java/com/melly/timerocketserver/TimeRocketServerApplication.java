package com.melly.timerocketserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TimeRocketServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(TimeRocketServerApplication.class, args);
    }

}
