package com.melly.timerocketserver.global.exception;

public class RocketNotFoundException extends RuntimeException {
    public RocketNotFoundException(String message) {
        super(message);
    }
}
