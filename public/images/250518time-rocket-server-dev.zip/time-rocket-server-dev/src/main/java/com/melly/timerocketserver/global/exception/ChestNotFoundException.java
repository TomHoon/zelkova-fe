package com.melly.timerocketserver.global.exception;

public class ChestNotFoundException extends RuntimeException {
    public ChestNotFoundException(String message) {
        super(message);
    }
}
